# SIQ Technologies - Glassmorphism AI Style Website

Inspired by a modern AI/SaaS glassmorphism landing page.

## Files
- index.html
- style.css

## Contact
HR@siq.info
(724) 200-3131

## Setup
Upload index.html and style.css to your GitHub Pages repository.

## Form
Replace YOUR_FORM_ID with your Formspree form ID.
